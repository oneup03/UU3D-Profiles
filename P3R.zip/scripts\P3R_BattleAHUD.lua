-- P3R_BattleAHUD.lua
-- Automatically toggles UEVR's "Compatibility -> AHUD" setting based on battle state.
--   In battle  -> AHUD Compatibility ON
--   Otherwise  -> AHUD Compatibility OFF
--
-- Battle detection uses the game's own authoritative check:
--   xrd777.BtlControlBase::CheckBattleInProgress()
-- The live battle actor is BP_BtlControl_C, which derives from ABtlControlBase.
-- UEVR's UObjectHook indexes every object under all of its super-classes, so
-- looking up the native base class finds the blueprint instance too.
--
-- Self-contained: uses only the raw UEVR API (no libs/ dependency).

local vr = uevr.params.vr

-- UEVR mod-value key (matches VR_Compatibility_AHUD in config.txt)
local AHUD_KEY = "VR_Compatibility_AHUD"

-- Candidate class paths for the battle-control actor's native base class.
-- FName comparison is case-insensitive, but we try a few spellings to be safe.
local BATTLE_CLASS_CANDIDATES = {
    "Class /Script/xrd777.BtlControlBase",
    "Class /Script/Xrd777.BtlControlBase",
}

-- How often to poll, in engine ticks. Battle transitions involve a level load,
-- so a few checks per second is plenty and keeps per-frame overhead near zero.
local POLL_INTERVAL = 6

-- ---------------------------------------------------------------------------

local g_battle_class = nil      -- resolved UClass for BtlControlBase
local g_control      = nil      -- cached BP_BtlControl_C instance
local g_last_state   = nil      -- last AHUD state we pushed (nil = unset)
local g_tick         = 0

local function obj_valid(o)
    return o ~= nil and UEVR_UObjectHook.exists(o)
end

-- Resolve the battle-control UClass once (cached). Returns the class or nil.
local function resolve_battle_class()
    if g_battle_class ~= nil then
        return g_battle_class
    end
    for _, name in ipairs(BATTLE_CLASS_CANDIDATES) do
        local ok, cls = pcall(function() return uevr.api:find_uobject(name) end)
        if ok and cls ~= nil then
            g_battle_class = cls
            print("[BattleAHUD] Resolved battle class: " .. name .. "\n")
            return g_battle_class
        end
    end
    return nil
end

-- Get a valid, live battle-control actor, or nil if none exists.
local function get_control()
    if obj_valid(g_control) then
        return g_control
    end
    g_control = nil

    local cls = resolve_battle_class()
    if cls == nil then
        return nil
    end

    -- includeDefault = false -> skip the CDO (Default__ object)
    local ok, inst = pcall(function()
        return UEVR_UObjectHook.get_first_object_by_class(cls, false)
    end)
    if ok and obj_valid(inst) then
        g_control = inst
        return g_control
    end
    return nil
end

-- True if a battle is currently in progress.
local function is_in_battle()
    local ctrl = get_control()
    if ctrl == nil then
        return false
    end
    -- CheckBattleInProgress() -> bool. Guard against reflection/lifetime errors.
    local ok, result = pcall(function()
        if ctrl.CheckBattleInProgress ~= nil then
            return ctrl:CheckBattleInProgress()
        end
        return false
    end)
    if not ok then
        -- Actor went stale between validation and the call; re-find next poll.
        g_control = nil
        return false
    end
    return result == true
end

-- Push the AHUD compatibility state (only when it changes).
local function apply(state)
    if state == g_last_state then
        return
    end
    g_last_state = state
    vr.set_mod_value(AHUD_KEY, state and "true" or "false")
    print("[BattleAHUD] AHUD Compatibility -> " .. (state and "ON (battle)" or "OFF") .. "\n")
end

-- Poll every POLL_INTERVAL engine ticks. get_control() re-finds the battle
-- actor whenever the cached one goes stale (e.g. after a level transition),
-- so no explicit level-change handling is needed.
uevr.sdk.callbacks.on_pre_engine_tick(function(engine, delta)
    g_tick = g_tick + 1
    if g_tick < POLL_INTERVAL then
        return
    end
    g_tick = 0

    apply(is_in_battle())
end)

print("[BattleAHUD] Loaded. Watching for P3R battle state.\n")
