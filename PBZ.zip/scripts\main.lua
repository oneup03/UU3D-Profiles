-- ================================================================
-- 影之刃零 Flat3D Slate UI 双渲修复 v7 (API 路径正确版)
--
-- 从 ScriptContext.cpp 逆向确认的 Lua 全局结构:
--   uevr.params.functions.log_info/warn/error(msg)
--   uevr.sdk.functions.execute_command(cmd)
--   uevr.sdk.functions.set_cvar_int(module, name, value)
--   uevr.sdk.callbacks.on_pre_engine_tick(fn)
--   uevr.sdk.callbacks.on_post_engine_tick(fn)
--   uevr.sdk.callbacks.on_pre_slate_draw_window(fn)
-- ================================================================

local applied = false

uevr.sdk.callbacks.on_pre_engine_tick(function(engine, delta)
    if applied then return end
    applied = true

    uevr.params.functions.log_info("[PBZ Lua] === Slate Dedicated UI OFF ===")

    -- 关掉 Dedicated Slate UI（UE 5.5+ 新特性导致右眼 HUD 丢失）
    uevr.sdk.functions.execute_command("r.SlateForUIViews.Dedicated 0")
    uevr.sdk.functions.execute_command("r.SlateForUIViews 0")

    -- 关掉 Instanced Stereo，强制 Separate
    uevr.sdk.functions.execute_command("r.Stereo.EnableInstancedStereo 0")
    uevr.sdk.functions.execute_command("r.SinglePass.Stereo 0")

    -- 强制 Slate/UMG stereo
    uevr.sdk.functions.execute_command("r.Slate.EnableStereoRendering 1")
    uevr.sdk.functions.execute_command("r.UMG.EnableStereoRendering 1")
    uevr.sdk.functions.execute_command("r.AllowOrthographicInStereo 1")

    -- 同时用 set_cvar_int 再设一次（双保险）
    uevr.sdk.functions.set_cvar_int("Engine", "r.SlateForUIViews.Dedicated", 0)
    uevr.sdk.functions.set_cvar_int("Engine", "r.Stereo.EnableInstancedStereo", 0)

    -- 多等几帧再强制一次
    local ticks = 0
    uevr.sdk.callbacks.on_post_engine_tick(function(engine2, delta2)
        ticks = ticks + 1
        if ticks % 10 == 0 and ticks < 80 then
            uevr.sdk.functions.execute_command("r.SlateForUIViews.Dedicated 0")
        end
    end)

    uevr.params.functions.log_info("[PBZ Lua] === Done ===")
end)

uevr.params.functions.log_info("[PBZ Lua] Script loaded")
